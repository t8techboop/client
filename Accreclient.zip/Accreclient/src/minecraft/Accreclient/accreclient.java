package Accreclient;

import com.sun.jna.platform.win32.WinBase.STARTUPINFO;

import Accreclient.util.SessionChanger;

public class accreclient {
	
	public String NAME = "Accreclient", VERSION = "1.0.0", AUTHOR = "Johnnyy290";
	public static accreclient INSTANCE = new accreclient();
	
	
	
	
	public void startup() {
		// TODO Auto-generated method stub

		System.out.println("starting " + " " + NAME + " " + VERSION + " by " + AUTHOR);
		
		SessionChanger.getInstance().setUserOffline("johnnyy290");
	}
	
	
	
	public void shutdown() {
		// TODO Auto-generated method stub
		
		System.out.println("shutting down" + " " + NAME + " " + VERSION + "... ");

	}

}
