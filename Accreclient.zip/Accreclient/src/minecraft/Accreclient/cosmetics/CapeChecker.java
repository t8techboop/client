package Accreclient.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;

public class CapeChecker {
	
	public static boolean ownsCape(AbstractClientPlayer entitylivingbaseIn) {
		if(entitylivingbaseIn.getName().equals("johnnyy290")) {
			return true;
			
		} else if(entitylivingbaseIn.getName().equals("DerRote123")) {
			return true;
		}
	     else if(entitylivingbaseIn.getName().equals("Mr_Mallard4468")) {
		    return true;
 	    }
		
		else return false;
	}

}
