package Accreclient.ui;

import java.awt.Color;
import java.io.IOException;

import com.google.common.math.Quantiles.Scale;

import Accreclient.accreclient;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiListWorldSelection;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiServerSelect;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.util.ResourceLocation;

public class accreclientmainmenu extends GuiScreen {

	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		mc.getTextureManager().bindTexture(new ResourceLocation("accrecraftclient/main_menu.png"));
		this.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, this.width, this.height, this.width, this.height);
		
		Gui.drawRect(0, 0, 225, this.height, new Color(0 ,0 ,0 ,170).getRGB());
		GlStateManager.pushMatrix();
		//GlStateManager.translate(width/2f, height/2f, 0);
		GlStateManager.scale(3, 3, 1);
		//GlStateManager.translate(-(width/2f) , -(height/2f), 0);
        this.drawCenteredString(mc.fontRendererObj, accreclient.INSTANCE.NAME, 35, height / 2 - 120, -1);
        this.drawCenteredString(mc.fontRendererObj, "v" + accreclient.INSTANCE.VERSION, 75, height / 1 - 120, -1);
        //mc.fontRendererObj.drawStringWithShadow("v" + accreclient.INSTANCE.VERSION, width/2f + -60, height/2f + -20 - mc.fontRendererObj.FONT_HEIGHT * 2f, new Color(0,255,0, 155).getRGB());
        GlStateManager.popMatrix();
		super.drawScreen(mouseX, mouseY, partialTicks);
	}
	
	@Override
	public void initGui() {
		// TODO Auto-generated method stub
		this.buttonList.add(new GuiButton(1, 10, height / 2 - 49, "single player"));
		this.buttonList.add(new GuiButton(2, 10, height / 2 - 25, "multiplayer"));
		this.buttonList.add(new GuiButton(3, 10, height / 2 - 0, "Dmu server"));
		this.buttonList.add(new GuiButton(4, 10, height / 2 - -25, "our server"));
		this.buttonList.add(new GuiButton(5, 10, height / 2 - -49, "options"));
		this.buttonList.add(new GuiButton(6, 10, height / 2 - -75, "rage quit/ quit game"));
		super.initGui();
	}
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		// TODO Auto-generated method stub
		if(button.id == 1) {
			mc.displayGuiScreen(new GuiWorldSelection(this));
			
		}
		if(button.id == 2) {
			mc.displayGuiScreen(new GuiMultiplayer(this));
			
		}
	    if(button.id == 4) {
		    mc.displayGuiScreen(new GuiServerSelect(this));
		
	    }
		
		if(button.id == 5) {
			mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings));
			
		}
		if(button.id == 6) {
			mc.shutdown();
			
		}
		super.actionPerformed(button);
	}
}
